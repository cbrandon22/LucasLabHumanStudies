#ifndef DRAW_OBJECT_H
#define DRAW_OBJECT_H

#include "object.h"

int  draw( ObjectData_T *object, int objectnum, int dispmode);
void init_lights( void );

#endif
